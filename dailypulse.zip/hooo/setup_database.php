<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Create connection
try {
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully<br>";
} catch (Exception $e) {
    die("Connection Error: " . $e->getMessage());
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === FALSE) {
    die("Error creating database: " . $conn->error);
}
echo "Database created successfully<br>";

// Select the database
$conn->select_db($dbname);

// Set charset
$conn->set_charset("utf8mb4");

// Drop existing tables in correct order to handle foreign key constraints
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DROP TABLE IF EXISTS comments");
$conn->query("DROP TABLE IF EXISTS news_articles");
$conn->query("DROP TABLE IF EXISTS categories");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");
echo "Old tables dropped successfully<br>";

// Create categories table
$sql = "CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === FALSE) {
    die("Error creating categories table: " . $conn->error);
}
echo "Categories table created successfully<br>";

// Insert categories
$categories = [
    ['टेक्नोलॉजी', 'Technology', 'technology'],
    ['खेल', 'Sports', 'sports'],
    ['व्यापार', 'Business', 'business'],
    ['मनोरंजन', 'Entertainment', 'entertainment'],
    ['राजनीति', 'Politics', 'politics'],
    ['क्राइम', 'Crime', 'crime']
];

$stmt = $conn->prepare("INSERT INTO categories (name, name_en, slug) VALUES (?, ?, ?)");
foreach ($categories as $category) {
    $stmt->bind_param("sss", $category[0], $category[1], $category[2]);
    if ($stmt->execute() === FALSE) {
        echo "Error inserting category {$category[1]}: " . $stmt->error . "<br>";
    } else {
        echo "Category {$category[1]} inserted successfully<br>";
    }
}
$stmt->close();

// Create news_articles table
$sql = "CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    image VARCHAR(255) NOT NULL,
    category_slug VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_slug) REFERENCES categories(slug)
)";

if ($conn->query($sql) === FALSE) {
    die("Error creating news_articles table: " . $conn->error);
}
echo "News articles table created successfully<br>";

// Create comments table
$sql = "CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES news_articles(id) ON DELETE CASCADE
)";

if ($conn->query($sql) === FALSE) {
    die("Error creating comments table: " . $conn->error);
}
echo "Comments table created successfully<br>";

// Create uploads directory if it doesn't exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
    echo "Uploads directory created successfully<br>";
}

echo "<br>Database setup completed successfully! You can now go to <a href='add_test_article.php'>add test articles</a> or return to <a href='in.php'>homepage</a>.";
$conn->close();
?> 