
  const articles = {
    technology: [
      { title: "Tech Article 1", description: "Description of tech article 1", city: "City A" },
      { title: "Tech Article 2", description: "Description of tech article 2", city: "City B" },
    ],
    sports: [
      { title: "Sports Article 1", description: "Description of sports article 1", city: "City C" },
      { title: "Sports Article 2", description: "Description of sports article 2", city: "City D" },
    ],
    business: [
      { title: "Business Article 1", description: "Description of business article 1", city: "City E" },
      { title: "Business Article 2", description: "Description of business article 2", city: "City F" },
    ],
    entertainment: [
      { title: "Entertainment Article 1", description: "Description of entertainment article 1", city: "City G" },
      { title: "Entertainment Article 2", description: "Description of entertainment article 2", city: "City H" },
    ],
  };

  function renderArticles(filteredArticles) {
    let totalArticles = 0;

    for (const category in filteredArticles) {
      const section = document.getElementById(category);
      const grid = section.querySelector('.news-grid');
      grid.innerHTML = ''; // Clear previous articles or messages

      const articlesArray = filteredArticles[category];
      
      if (articlesArray && articlesArray.length > 0) {
        // Show the entire category section if it was hidden
        section.style.display = '';
        // Render articles
        articlesArray.forEach(article => {
          const articleElement = document.createElement('article');
          articleElement.className = 'news-article';
          articleElement.innerHTML = `
            <div class="news-image-wrapper">
              <img src="m.jpg" alt="${article.title}">
            </div>
            <div class="news-content">
              <h3 class="news-header">${article.title}</h3>
              <p class="news-description">${article.description}</p>
              <p class="news-city">${article.city}</p>
              <button class="read-more-btn">Read More</button>
            </div>
          `;
          grid.appendChild(articleElement);
          totalArticles++;
        });
      } else {
        // No articles in this category, hide the category section entirely
        section.style.display = 'none';
      }
    }

    // If no articles found in all categories, show a global no-articles message
    if (totalArticles === 0) {
      // Create or find a global message container below the search box
      let globalNoArticlesMsg = document.getElementById('global-no-articles-message');
      if (!globalNoArticlesMsg) {
        globalNoArticlesMsg = document.createElement('p');
        globalNoArticlesMsg.id = 'global-no-articles-message';
        globalNoArticlesMsg.className = 'no-articles';
        globalNoArticlesMsg.textContent = 'No articles found for your search in any category.';
        const mainContainer = document.querySelector('main.container');
        mainContainer.appendChild(globalNoArticlesMsg);
      }
    } else {
      // Remove the global no-articles message if present
      const existingMsg = document.getElementById('global-no-articles-message');
      if (existingMsg) {
        existingMsg.remove();
      }
    }
  }

  function filterArticles() {
    const searchInput = document.getElementById('city-search').value.trim().toLowerCase();
    if (searchInput === '') {
      // Show all categories and all articles
      // Remove global no articles message if any
      const existingMsg = document.getElementById('global-no-articles-message');
      if (existingMsg) {
        existingMsg.remove();
      }
      // Show all category sections
      for (const category in articles) {
        const section = document.getElementById(category);
        section.style.display = '';
      }
      renderArticles(articles);
      return;
    }

    const filteredArticles = {};
    for (const category in articles) {
      filteredArticles[category] = articles[category].filter(article =>
        article.city.toLowerCase().includes(searchInput)
      );
    }

    renderArticles(filteredArticles);
  }

  document.addEventListener('DOMContentLoaded', () => {
    renderArticles(articles); // Initial full render
    document.getElementById('city-search').addEventListener('input', filterArticles);
  });