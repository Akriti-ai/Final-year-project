<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";

try {
    // Create connection without database
    $conn = new mysqli($servername, $username, $password);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS daily_pulse";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully<br>";
    } else {
        throw new Exception("Error creating database: " . $conn->error);
    }

    // Select the database
    $conn->select_db("daily_pulse");

    // Drop existing table if exists
    $sql = "DROP TABLE IF EXISTS news_articles";
    $conn->query($sql);

    // Create table with updated structure
    $sql = "CREATE TABLE news_articles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        city VARCHAR(100) NOT NULL,
        category ENUM('technology', 'sports', 'business', 'entertainment') NOT NULL,
        image VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    if ($conn->query($sql) === TRUE) {
        echo "Table created successfully<br>";
    } else {
        throw new Exception("Error creating table: " . $conn->error);
    }

    echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; margin: 10px 0; border-radius: 4px;'>
            Setup completed successfully! You can now use the main application.
            <br><br>
            <a href='in.php' style='color: #155724; text-decoration: underline;'>Go to main page</a>
          </div>";

} catch (Exception $e) {
    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; margin: 10px 0; border-radius: 4px;'>
            Error: " . $e->getMessage() . "
            <br><br>
            Please make sure:
            <ul style='margin-left: 20px;'>
                <li>XAMPP is running</li>
                <li>MySQL service is started in XAMPP Control Panel</li>
                <li>The root user has no password set (default XAMPP configuration)</li>
            </ul>
          </div>";
}

if (isset($conn)) {
    $conn->close();
}
?> 