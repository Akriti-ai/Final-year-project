<?php
// Set the content type to image/jpeg
header('Content-Type: image/jpeg');

// Create a new image
$width = 800;
$height = 600;
$image = imagecreatetruecolor($width, $height);

// Define colors
$bg_color = imagecolorallocate($image, 240, 240, 240);
$text_color = imagecolorallocate($image, 100, 100, 100);

// Fill the background
imagefilledrectangle($image, 0, 0, $width, $height, $bg_color);

// Add text
$text = "No Image Available";
imagestring($image, 5, ($width/2) - 70, ($height/2) - 10, $text, $text_color);

// Create uploads directory if it doesn't exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Save the image
imagejpeg($image, 'uploads/default.jpg', 90);
imagedestroy($image);

echo "Default image has been created successfully!";
?> 