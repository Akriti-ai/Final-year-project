// Translations object containing both Hindi and English translations
const translations = {
    'en': {
        'daily_pulse': 'Daily Pulse',
        'home': 'Home',
        'technology': 'Technology',
        'sports': 'Sports',
        'business': 'Business',
        'entertainment': 'Entertainment',
        'politics': 'Politics',
        'crime': 'Crime',
        'add_article': 'Add Article',
        'popular_news': 'Popular News',
        'comments': 'Comments',
        'views': 'Views',
        'previous': 'Previous',
        'next': 'Next'
    },
    'hi': {
        'daily_pulse': 'डेली पल्स',
        'home': 'होम',
        'technology': 'टेक्नोलॉजी',
        'sports': 'खेल',
        'business': 'व्यापार',
        'entertainment': 'मनोरंजन',
        'politics': 'राजनीति',
        'crime': 'क्राइम',
        'add_article': 'लेख जोड़ें',
        'popular_news': 'लोकप्रिय समाचार',
        'comments': 'टिप्पणियां',
        'views': 'व्यूज',
        'previous': 'पिछला',
        'next': 'अगला'
    }
};

// Get current language from localStorage or default to Hindi
let currentLang = localStorage.getItem('language') || 'hi';

// Initial page load translation
document.addEventListener('DOMContentLoaded', () => {
    updateLanguageButton();
    translatePage();
});

// Function to switch language
function switchLanguage() {
    // Toggle between Hindi and English
    currentLang = currentLang === 'hi' ? 'en' : 'hi';
    
    // Save language preference
    localStorage.setItem('language', currentLang);
    
    // Update button text and translate page
    updateLanguageButton();
    translatePage();
}

// Function to update language button text
function updateLanguageButton() {
    const langButton = document.getElementById('langSwitch');
    if (langButton) {
        const buttonText = currentLang === 'hi' ? 'English' : 'हिंदी';
        langButton.querySelector('span').textContent = buttonText;
    }
}

// Function to translate the page
function translatePage() {
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[currentLang][key]) {
            element.textContent = translations[currentLang][key];
        }
    });
} 