// Wait for all resources to load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize image loading
    initializeImageLoading();
    
    // Initialize page loading
    initializePageLoading();
});

// Handle image loading
function initializeImageLoading() {
    const images = document.querySelectorAll('img[loading="lazy"]');
    
    // Create IntersectionObserver for lazy loading
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                }
                img.onload = () => img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });

    // Observe each image
    images.forEach(img => {
        // Store original src in data-src
        if (img.src) {
            img.dataset.src = img.src;
            img.src = '';
        }
        imageObserver.observe(img);
    });
}

// Handle page loading
function initializePageLoading() {
    // Hide loader and show content when everything is loaded
    window.addEventListener('load', () => {
        document.body.classList.add('ready');
        const loader = document.querySelector('.page-loader');
        if (loader) {
            loader.classList.add('hidden');
            setTimeout(() => {
                loader.style.display = 'none';
            }, 300);
        }
    });
}

// Handle language switching
function switchLanguage() {
    const currentLang = localStorage.getItem('language') || 'hi';
    const newLang = currentLang === 'hi' ? 'en' : 'hi';
    
    localStorage.setItem('language', newLang);
    
    // Update button text
    const langButton = document.getElementById('langSwitch');
    if (langButton) {
        langButton.querySelector('span').textContent = newLang === 'hi' ? 'English' : 'हिंदी';
    }
    
    // Update translations
    updatePageTranslations();
}

// Update page translations
function updatePageTranslations() {
    const currentLang = localStorage.getItem('language') || 'hi';
    const elements = document.querySelectorAll('[data-translate]');
    
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[key]) {
            element.textContent = translations[key][currentLang];
        }
    });
} 