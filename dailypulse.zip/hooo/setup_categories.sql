-- Drop the existing categories table if it exists
DROP TABLE IF EXISTS categories;

-- Create the categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert the specified categories
INSERT INTO categories (name, slug) VALUES
('Technology', 'technology'),
('Sports', 'sports'),
('Business', 'business'),
('Entertainment', 'entertainment'),
('Politics', 'politics'),
('Crime', 'crime'); 