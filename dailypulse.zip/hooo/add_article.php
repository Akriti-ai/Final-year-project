<?php
session_start();
ob_start();

// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Create connection with error handling
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("<div class='alert alert-error'>Database Error: " . $e->getMessage() . "<br>Please make sure MySQL is running in XAMPP.</div>");
}

$conn->set_charset("utf8mb4");

// Fetch all categories
$sql = "SELECT * FROM categories ORDER BY name";
$result = $conn->query($sql);
$categories = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$message = '';
$redirect = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $city = $conn->real_escape_string($_POST['city']);
    $category_slug = $conn->real_escape_string($_POST['category']);

    // Handle image upload
    $uploadOk = 1;
    $uploadDir = "uploads/";
    
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $uniqueFilename = uniqid() . '.' . $imageFileType;
    $uploadFile = $uploadDir . $uniqueFilename;

    if(isset($_FILES["image"]) && $_FILES["image"]["tmp_name"] != "") {
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check === false) {
            $message .= "<div class='alert alert-error'>File is not an image.</div>";
            $uploadOk = 0;
        }
    } else {
        $message .= "<div class='alert alert-error'>No image file uploaded.</div>";
        $uploadOk = 0;
    }

    if ($_FILES["image"]["size"] > 5000000) {
        $message .= "<div class='alert alert-error'>Sorry, your file is too large. Max size is 5MB.</div>";
        $uploadOk = 0;
    }

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        $message .= "<div class='alert alert-error'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadFile)) {
            $sql = "INSERT INTO news_articles (title, description, city, category_slug, image) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $title, $description, $city, $category_slug, $uploadFile);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "News article has been added successfully!";
                $redirect = true;
            } else {
                $message .= "<div class='alert alert-error'>Error: " . $stmt->error . "</div>";
                unlink($uploadFile);
            }
            $stmt->close();
        } else {
            $message .= "<div class='alert alert-error'>Sorry, there was an error uploading your file.</div>";
        }
    }
}

if ($redirect) {
    ob_end_clean();
    header("Location: in.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Article - Daily Pulse</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f4f4;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #2c3e50;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            border-color: #2c3e50;
            outline: none;
        }

        .form-group textarea {
            height: 150px;
            resize: vertical;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .submit-btn, .back-btn {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            flex: 1;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .submit-btn {
            background-color: #2c3e50;
            color: white;
        }

        .submit-btn:hover {
            background-color: #34495e;
        }

        .back-btn {
            background-color: #95a5a6;
            color: white;
        }

        .back-btn:hover {
            background-color: #7f8c8d;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            font-weight: 500;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .preview-image {
            max-width: 200px;
            max-height: 200px;
            margin-top: 10px;
            display: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Article</h1>
        
        <?php if(!empty($message)) echo $message; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" id="title" name="title" required>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" required></textarea>
            </div>

            <div class="form-group">
                <label for="city">City</label>
                <input type="text" id="city" name="city" required>
            </div>

            <div class="form-group">
                <label for="category">Category:</label>
                <select name="category" id="category" required>
                    <option value="">Select a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo htmlspecialchars($category['slug']); ?>">
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" id="image" name="image" accept="image/*" required onchange="previewImage(this)">
                <img id="preview" class="preview-image">
            </div>

            <div class="button-group">
                <a href="in.php" class="back-btn">Back to Home</a>
                <button type="submit" class="submit-btn">Add Article</button>
            </div>
        </form>
    </div>

    <script>
        function previewImage(input) {
            const preview = document.getElementById('preview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html> 