-- Create database if not exists
CREATE DATABASE IF NOT EXISTS daily_pulse;
USE daily_pulse;

-- Create news_articles table
CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    category ENUM('technology', 'sports', 'business', 'entertainment') NOT NULL,
    image VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE
);

-- Insert default categories
INSERT INTO categories (name, slug) VALUES 
('टेक्नोलॉजी', 'technology'),
('खेल', 'sports'),
('बिजनेस', 'business'),
('मनोरंजन', 'entertainment'),
('राजनीति', 'politics'),
('क्राइम', 'crime');

-- Add new columns to news_articles table
ALTER TABLE news_articles 
ADD COLUMN IF NOT EXISTS views INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS category_slug VARCHAR(50),
ADD FOREIGN KEY (category_slug) REFERENCES categories(slug);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT,
    user_name VARCHAR(100),
    comment_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES news_articles(id)
); 