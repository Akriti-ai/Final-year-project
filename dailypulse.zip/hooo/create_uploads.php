<?php
// Set appropriate headers
header('Content-Type: application/json');

// Define upload directory
$uploadDir = 'uploads';

// Create directory if it doesn't exist
if (!file_exists($uploadDir)) {
    if (mkdir($uploadDir, 0777, true)) {
        echo json_encode(['success' => true, 'message' => 'Uploads directory created successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create uploads directory']);
    }
} else {
    echo json_encode(['success' => true, 'message' => 'Uploads directory already exists']);
}
?> 