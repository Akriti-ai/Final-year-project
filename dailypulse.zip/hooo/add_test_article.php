<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Create connection
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Set charset
$conn->set_charset("utf8mb4");

// Make sure uploads directory exists
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Make sure default.jpg exists
if (!file_exists('uploads/default.jpg')) {
    // Create a simple default image using GD
    $width = 800;
    $height = 600;
    $image = imagecreatetruecolor($width, $height);
    $bg_color = imagecolorallocate($image, 240, 240, 240);
    $text_color = imagecolorallocate($image, 100, 100, 100);
    imagefilledrectangle($image, 0, 0, $width, $height, $bg_color);
    $text = "No Image Available";
    imagestring($image, 5, ($width/2) - 70, ($height/2) - 10, $text, $text_color);
    imagejpeg($image, 'uploads/default.jpg', 90);
    imagedestroy($image);
}

// Add a test article for each category
$categories = ['technology', 'sports', 'business', 'entertainment', 'politics', 'crime'];
$cities = ['दिल्ली', 'मुंबई', 'बैंगलोर', 'हैदराबाद', 'चेन्नई', 'कोलकाता'];

// First, clear existing articles
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("TRUNCATE TABLE news_articles");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

foreach ($categories as $index => $category) {
    $title = "टेस्ट समाचार - " . date('Y-m-d') . " - " . $category;
    $description = "यह एक टेस्ट समाचार है जो यह देखने के लिए जोड़ा गया है कि वेबसाइट सही तरीके से काम कर रही है या नहीं।";
    $image = "./uploads/default.jpg";  // Updated image path
    $city = $cities[$index];
    
    $stmt = $conn->prepare("INSERT INTO news_articles (title, description, image, category_slug, city) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $description, $image, $category, $city);
    
    if ($stmt->execute() === FALSE) {
        echo "Error adding test article for $category: " . $stmt->error . "<br>";
    } else {
        echo "Test article added for $category successfully!<br>";
    }
    $stmt->close();
}

$conn->close();
echo "<br>Test articles added successfully! <a href='in.php'>Go to homepage</a>";
?> 