<?php
header('Content-Type: application/json');
session_start();

// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Enable error logging
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/php_errors.log');

// Ensure no output before headers
ob_start();

// Ensure proper error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Log request data for debugging
error_log("Received POST data: " . print_r($_POST, true));

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'error' => $e->getMessage()]);
    ob_end_flush();
    exit();
}

$conn->set_charset("utf8mb4");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $article_id = isset($_POST['article_id']) ? (int)$_POST['article_id'] : 0;
    $name = $conn->real_escape_string($_POST['name']);
    $comment = $conn->real_escape_string($_POST['comment']);
    
    if (!$article_id || !$name || !$comment) {
        error_log("Missing required fields. POST data: " . print_r($_POST, true));
        echo json_encode(['status' => 'error', 'error' => 'All fields are required']);
        ob_end_flush();
        exit();
    }
    
    // Insert the comment
    $sql = "INSERT INTO comments (article_id, name, comment) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $article_id, $name, $comment);
    
    if ($stmt->execute()) {
        // Get the newly inserted comment
        $comment_id = $stmt->insert_id;
        $stmt->close();
        
        // Fetch the comment details
        $sql = "SELECT id, name, comment as comment_text, created_at FROM comments WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $comment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $comment = $result->fetch_assoc();
        $stmt->close();
        
        // Get total comments count for this article
        $sql = "SELECT COUNT(*) as total FROM comments WHERE article_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $article_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->fetch_assoc();
        $stmt->close();
        
        // Format the date
        $comment['created_at'] = date('d M Y', strtotime($comment['created_at']));
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Comment added successfully',
            'comment' => $comment,
            'total_comments' => $count['total']
        ]);
    } else {
        error_log("Failed to insert comment: " . $stmt->error);
        echo json_encode(['status' => 'error', 'error' => 'Error adding comment']);
    }
    
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'error' => 'Invalid request method']);
}
ob_end_flush();
?> 