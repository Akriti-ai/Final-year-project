<?php
session_start();
ob_start();

// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("<div class='alert alert-error'>Database Error: " . $e->getMessage() . "</div>");
}

$conn->set_charset("utf8mb4");

// Fetch all comments with article information
$sql = "SELECT c.id, c.name as user_name, c.comment as comment_text, c.created_at, 
        a.title as article_title, a.id as article_id 
        FROM comments c 
        LEFT JOIN news_articles a ON c.article_id = a.id 
        ORDER BY c.created_at DESC";
$result = $conn->query($sql);
$comments = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>सभी टिप्पणियां - Daily Pulse</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Reuse existing styles from in.php */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --text-color: #333;
            --light-gray: #f4f4f4;
            --border-color: #ddd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Comments specific styles */
        .comments-container {
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .page-title {
            color: var(--primary-color);
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--secondary-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .comment-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }

        .comment-card:hover {
            transform: translateY(-2px);
        }

        .comment-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .comment-author {
            font-weight: bold;
            color: var(--primary-color);
        }

        .comment-date {
            color: #666;
        }

        .comment-text {
            margin-bottom: 1rem;
            line-height: 1.6;
        }

        .article-link {
            display: inline-block;
            color: var(--secondary-color);
            text-decoration: none;
            font-weight: bold;
        }

        .article-link:hover {
            text-decoration: underline;
        }

        .no-comments {
            text-align: center;
            padding: 2rem;
            color: #666;
            font-style: italic;
        }

        /* Header and Navigation styles from in.php */
        header {
            background-color: var(--primary-color);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .logo {
            color: white;
            font-size: 2rem;
            text-decoration: none;
            font-weight: bold;
        }

        .nav-menu {
            background-color: #34495e;
            padding: 0.5rem 0;
        }

        .nav-list {
            display: flex;
            list-style: none;
            gap: 1.5rem;
            justify-content: center;
        }

        .nav-list a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav-list a:hover {
            background-color: var(--secondary-color);
        }

        /* Add new header button styles */
        .header-buttons {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .header-btn {
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .header-btn:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        .header-btn i {
            font-size: 1.2rem;
        }

        .lang-switch {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .lang-switch:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        .lang-switch i {
            font-size: 1.2rem;
        }

        @media (max-width: 768px) {
            .header-buttons {
                flex-direction: column;
                gap: 5px;
            }

            .header-btn, .lang-switch {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-top">
                <a href="in.php" class="logo">Daily Pulse</a>
                <div class="header-right">
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                    <div class="header-buttons">
                        <a href="comments.php" class="header-btn" data-translate="comments">
                            <i class="far fa-comments"></i> टिप्पणियां
                        </a>
                        <a href="messages.php" class="header-btn" data-translate="messages">
                            <i class="far fa-envelope"></i> संदेश
                        </a>
                        <button id="langSwitch" class="lang-switch" onclick="switchLanguage()">
                            <i class="fas fa-language"></i>
                            <span>English</span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="nav-menu">
                <ul class="nav-list">
                    <li><a href="in.php" data-translate="home">होम</a></li>
                    <li><a href="add_article.php" data-translate="add_article">लेख जोड़ें</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="comments-container">
            <h1 class="page-title">
                <i class="far fa-comments"></i>
                <span data-translate="all_comments">सभी टिप्पणियां</span>
            </h1>

            <?php if (empty($comments)): ?>
                <div class="no-comments" data-translate="no_comments">
                    कोई टिप्पणी नहीं मिली
                </div>
            <?php else: ?>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment-card">
                        <div class="comment-header">
                            <span class="comment-author"><?php echo htmlspecialchars($comment['user_name']); ?></span>
                            <span class="comment-date">
                                <i class="far fa-calendar"></i>
                                <?php echo date('d M Y', strtotime($comment['created_at'])); ?>
                            </span>
                        </div>
                        <div class="comment-text">
                            <?php echo nl2br(htmlspecialchars($comment['comment_text'])); ?>
                        </div>
                        <a href="article.php?id=<?php echo $comment['article_id']; ?>" class="article-link">
                            <i class="far fa-newspaper"></i>
                            <?php echo htmlspecialchars($comment['article_title']); ?>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script>
        // Language switch functionality
        let isHindi = true;
        const translations = {
            hindi: {
                home: 'होम',
                add_article: 'लेख जोड़ें',
                comments: 'टिप्पणियां',
                messages: 'संदेश',
                all_comments: 'सभी टिप्पणियां',
                no_comments: 'कोई टिप्पणी नहीं मिली'
            },
            english: {
                home: 'Home',
                add_article: 'Add Article',
                comments: 'Comments',
                messages: 'Messages',
                all_comments: 'All Comments',
                no_comments: 'No comments found'
            }
        };

        function switchLanguage() {
            isHindi = !isHindi;
            const lang = isHindi ? 'hindi' : 'english';
            
            // Update all translatable elements
            document.querySelectorAll('[data-translate]').forEach(element => {
                const key = element.getAttribute('data-translate');
                if (translations[lang][key]) {
                    element.textContent = translations[lang][key];
                }
            });
        }
    </script>
</body>
</html>
<?php ob_end_flush(); ?> 