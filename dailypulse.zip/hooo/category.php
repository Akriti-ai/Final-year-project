<?php
session_start();
ob_start();

// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Create connection
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Set charset
$conn->set_charset("utf8mb4");

// Get category slug from URL
$category_slug = isset($_GET['category']) ? $_GET['category'] : '';

// Fetch category details
$category = null;
if ($category_slug) {
    $stmt = $conn->prepare("SELECT * FROM categories WHERE slug = ?");
    $stmt->bind_param("s", $category_slug);
    $stmt->execute();
    $result = $stmt->get_result();
    $category = $result->fetch_assoc();
    $stmt->close();
}

if (!$category) {
    header("Location: in.php");
    exit();
}

// Fetch articles for this category with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$articles_per_page = 10;
$offset = ($page - 1) * $articles_per_page;

$stmt = $conn->prepare("
    SELECT a.*, c.name as category_name, COUNT(cm.id) as comment_count 
    FROM news_articles a 
    LEFT JOIN categories c ON a.category_slug = c.slug 
    LEFT JOIN comments cm ON a.id = cm.article_id 
    WHERE a.category_slug = ?
    GROUP BY a.id 
    ORDER BY a.created_at DESC 
    LIMIT ? OFFSET ?
");

$stmt->bind_param("sii", $category_slug, $articles_per_page, $offset);
$stmt->execute();
$articles = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get total articles count for pagination
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM news_articles WHERE category_slug = ?");
$stmt->bind_param("s", $category_slug);
$stmt->execute();
$total_articles = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

$total_pages = ceil($total_articles / $articles_per_page);

// Fetch popular articles in this category
$stmt = $conn->prepare("
    SELECT a.*, COUNT(cm.id) as comment_count 
    FROM news_articles a 
    LEFT JOIN comments cm ON a.id = cm.article_id 
    WHERE a.category_slug = ?
    GROUP BY a.id 
    ORDER BY a.views DESC 
    LIMIT 5
");
$stmt->bind_param("s", $category_slug);
$stmt->execute();
$popular_articles = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category['name']); ?> - Daily Pulse</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Reuse the same styles from in.php */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --text-color: #333;
            --light-gray: #f4f4f4;
            --border-color: #ddd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Header Styles */
        header {
            background-color: var(--primary-color);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .logo {
            color: white;
            font-size: 2rem;
            text-decoration: none;
            font-weight: bold;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .social-links a {
            color: white;
            margin-left: 15px;
            font-size: 1.2rem;
        }

        .lang-switch {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .nav-menu {
            background-color: #34495e;
            padding: 0.5rem 0;
        }

        .nav-list {
            display: flex;
            list-style: none;
            gap: 1.5rem;
            justify-content: center;
        }

        .nav-list a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav-list a:hover {
            background-color: var(--secondary-color);
        }

        /* Main Content Styles */
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin: 2rem 0;
        }

        .category-header {
            background-color: white;
            padding: 1rem;
            margin-bottom: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .category-title {
            color: var(--primary-color);
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .news-grid {
            display: grid;
            gap: 1.5rem;
        }

        .news-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .news-card:hover {
            transform: translateY(-5px);
        }

        .news-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .news-content {
            padding: 1.5rem;
        }

        .news-title {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .news-meta {
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 0.9rem;
        }

        /* Sidebar Styles */
        .sidebar {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .sidebar-title {
            color: var(--primary-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--secondary-color);
        }

        .popular-list {
            list-style: none;
        }

        .popular-item {
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .popular-item:last-child {
            border-bottom: none;
        }

        .popular-link {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .popular-image {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }

        /* Pagination Styles */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin: 2rem 0;
        }

        .pagination a {
            color: var(--primary-color);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            transition: all 0.3s;
        }

        .pagination a:hover,
        .pagination a.active {
            background-color: var(--primary-color);
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .header-top {
                flex-direction: column;
                text-align: center;
            }

            .nav-list {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-top">
                <a href="in.php" class="logo" data-translate="daily_pulse">Daily Pulse</a>
                <div class="header-right">
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                    <button id="langSwitch" class="lang-switch" onclick="switchLanguage()">
                        <i class="fas fa-language"></i>
                        <span>English</span>
                    </button>
                </div>
            </div>
            <nav class="nav-menu">
                <ul class="nav-list">
                    <li><a href="in.php" data-translate="home">होम</a></li>
                    <li><a href="category.php?category=technology" data-translate="technology">टेक्नॉलॉजी</a></li>
                    <li><a href="category.php?category=sports" data-translate="sports">खेल</a></li>
                    <li><a href="category.php?category=business" data-translate="business">व्यापार</a></li>
                    <li><a href="category.php?category=entertainment" data-translate="entertainment">मनोरंजन</a></li>
                    <li><a href="category.php?category=politics" data-translate="politics">राजनीति</a></li>
                    <li><a href="category.php?category=crime" data-translate="crime">क्राइम</a></li>
                    <li><a href="add_article.php" data-translate="add_article">लेख जोड़ें</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="category-header">
            <h1 class="category-title" data-translate="<?php echo htmlspecialchars($category_slug); ?>">
                <?php echo htmlspecialchars($category['name']); ?>
            </h1>
        </div>

        <div class="main-content">
            <div class="news-grid">
                <?php if (empty($articles)): ?>
                    <div class="no-articles">
                        <p>इस श्रेणी में कोई समाचार नहीं है।</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($articles as $article): ?>
                        <article class="news-card">
                            <a href="article.php?id=<?php echo $article['id']; ?>" style="text-decoration: none; color: inherit;">
                                <img src="<?php echo htmlspecialchars($article['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($article['title']); ?>" 
                                     class="news-image"
                                     onerror="this.src='uploads/default.jpg'">
                                <div class="news-content">
                                    <h2 class="news-title"><?php echo htmlspecialchars($article['title']); ?></h2>
                                    <div class="news-meta">
                                        <span><i class="far fa-calendar"></i> <?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                        <span><i class="far fa-comment"></i> <?php echo $article['comment_count']; ?> टिप्पणियां</span>
                                        <span><i class="far fa-eye"></i> <?php echo $article['views']; ?> व्यूज</span>
                                    </div>
                                </div>
                            </a>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <aside class="sidebar">
                <h3 class="sidebar-title" data-translate="popular_news">लोकप्रिय समाचार</h3>
                <ul class="popular-list">
                    <?php foreach ($popular_articles as $article): ?>
                        <li class="popular-item">
                            <a href="article.php?id=<?php echo $article['id']; ?>" class="popular-link">
                                <img src="<?php echo htmlspecialchars($article['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($article['title']); ?>" 
                                     class="popular-image"
                                     onerror="this.src='uploads/default.jpg'">
                                <div>
                                    <h4><?php echo htmlspecialchars($article['title']); ?></h4>
                                    <span><i class="far fa-calendar"></i> <?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                </div>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </aside>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?category=<?php echo $category_slug; ?>&page=<?php echo ($page - 1); ?>">
                        <i class="fas fa-chevron-left"></i> Previous
                    </a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?category=<?php echo $category_slug; ?>&page=<?php echo $i; ?>" 
                       class="<?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?category=<?php echo $category_slug; ?>&page=<?php echo ($page + 1); ?>">
                        Next <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script src="js/translations.js"></script>
</body>
</html>
<?php ob_end_flush(); ?> 