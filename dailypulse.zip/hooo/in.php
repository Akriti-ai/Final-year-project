<?php
// Start the session and buffer
session_start();
ob_start();

// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "daily_pulse";

// Create connection with error handling
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("<div class='alert alert-error'>Database Error: " . $e->getMessage() . "<br>Please make sure MySQL is running in XAMPP.</div>");
}

// Set charset to handle special characters
$conn->set_charset("utf8mb4");

$message = '';
$redirect = false;

// Fetch categories
$categories = [];
$sql = "SELECT * FROM categories ORDER BY id";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Get category from URL
$category = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : null;

// Fetch latest articles with comment counts
$latest_articles = [];
$sql = "SELECT a.*, c.name as category_name, COUNT(cm.id) as comment_count 
        FROM news_articles a 
        LEFT JOIN categories c ON a.category_slug = c.slug
        LEFT JOIN comments cm ON a.id = cm.article_id ";

// Add category filter if category is specified
if ($category) {
    $sql .= "WHERE a.category_slug = ? ";
}

$sql .= "GROUP BY a.id 
         ORDER BY a.created_at DESC 
         LIMIT 10";

if ($category) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $latest_articles[] = $row;
    }
}

if (isset($stmt)) {
    $stmt->close();
}

// Fetch popular articles
$popular_articles = [];
$sql = "SELECT a.*, c.name as category_name 
        FROM news_articles a 
        LEFT JOIN categories c ON a.category_slug = c.slug 
        ORDER BY a.views DESC 
        LIMIT 5";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $popular_articles[] = $row;
    }
}

$conn->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $city = $conn->real_escape_string($_POST['city']);
    $category = $conn->real_escape_string($_POST['category']);

    // Handle image upload
    $uploadOk = 1;
    $uploadDir = "uploads/";
    
    // Create uploads directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Generate unique filename
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $uniqueFilename = uniqid() . '.' . $imageFileType;
    $uploadFile = $uploadDir . $uniqueFilename;

    // Check if image file is actual image
    if(isset($_FILES["image"]) && $_FILES["image"]["tmp_name"] != "") {
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check === false) {
            $message .= "<div class='alert alert-error'>File is not an image.</div>";
            $uploadOk = 0;
        }
    } else {
        $message .= "<div class='alert alert-error'>No image file uploaded.</div>";
        $uploadOk = 0;
    }

    // Check file size (5MB max)
    if ($_FILES["image"]["size"] > 5000000) {
        $message .= "<div class='alert alert-error'>Sorry, your file is too large. Max size is 5MB.</div>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        $message .= "<div class='alert alert-error'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload file and save to database
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadFile)) {
            // Insert into database
            $sql = "INSERT INTO news_articles (title, description, city, category, image) 
                    VALUES (?, ?, ?, ?, ?)";
            
            // Use prepared statement to prevent SQL injection
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $title, $description, $city, $category, $uploadFile);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "News article has been added successfully!";
                $redirect = true;
            } else {
                $message .= "<div class='alert alert-error'>Error: " . $stmt->error . "</div>";
                // Delete uploaded file if database insert failed
                unlink($uploadFile);
            }
            $stmt->close();
        } else {
            $message .= "<div class='alert alert-error'>Sorry, there was an error uploading your file.</div>";
        }
    }
}

// If redirect is needed, do it before any output
if ($redirect) {
    ob_end_clean(); // Clear any output
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Now we can start the HTML output
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Pulse - ताज़ा खबरें</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --text-color: #333;
            --light-gray: #f4f4f4;
            --border-color: #ddd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Header Styles */
        header {
            background-color: var(--primary-color);
            padding: 0.3rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow: visible;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.3rem;
            position: relative;
        }

        .logo {
            color: white;
            font-size: 2.8rem;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 0;
        }

        .logo span {
            color: white;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .social-links a {
            color: white;
            margin-left: 15px;
            font-size: 1.2rem;
        }

        .lang-switch {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .lang-switch:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        .lang-switch i {
            font-size: 1.2rem;
        }

        .nav-menu {
            background-color: #34495e;
            padding: 0.2rem 0;
        }

        .nav-list {
            display: flex;
            list-style: none;
            gap: 0.8rem;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }

        .nav-list a {
            color: white;
            text-decoration: none;
            padding: 0.2rem 0.6rem;
            border-radius: 4px;
            transition: background-color 0.3s;
            font-size: 0.9rem;
        }

        .nav-list a:hover {
            background-color: var(--secondary-color);
        }

        /* Main Content Styles */
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin: 2rem 0;
        }

        .news-grid {
            display: grid;
            gap: 1.5rem;
        }

        .news-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .news-card:hover {
            transform: translateY(-5px);
        }

        .news-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .news-content {
            padding: 1.5rem;
        }

        .news-category {
            color: var(--secondary-color);
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .news-title {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .news-meta {
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 0.9rem;
        }

        /* Sidebar Styles */
        .sidebar {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .sidebar-title {
            color: var(--primary-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--secondary-color);
        }

        .popular-list {
            list-style: none;
        }

        .popular-item {
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .popular-item:last-child {
            border-bottom: none;
        }

        .popular-link {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .popular-image {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .header-top {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .header-right {
                flex-direction: column;
                gap: 10px;
            }

            .lang-switch {
                margin: 10px 0;
            }

            .nav-list {
                gap: 0.5rem;
            }
        }

        .header-buttons {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .header-btn {
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .header-btn:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        .header-btn i {
            font-size: 1.2rem;
        }

        @media (max-width: 768px) {
            .header-buttons {
                flex-direction: column;
                gap: 5px;
            }

            .header-btn, .lang-switch {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-top">
                <a href="in.php" class="logo" data-translate="daily_pulse">Daily Pulse</a>
                <div class="header-right">
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                    <div class="header-buttons">
                        <a href="comments.php" class="header-btn" data-translate="comments">
                            <i class="far fa-comments"></i> टिप्पणियां
                        </a>
                        <a href="messages.php" class="header-btn" data-translate="messages">
                            <i class="far fa-envelope"></i> संदेश
                        </a>
                        <button id="langSwitch" class="lang-switch" onclick="switchLanguage()">
                            <i class="fas fa-language"></i>
                            <span>English</span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="nav-menu">
                <ul class="nav-list">
                    <li><a href="in.php" data-translate="home">होम</a></li>
                    <?php foreach ($categories as $category): ?>
                        <li>
                            <a href="category.php?category=<?php echo $category['slug']; ?>" 
                               data-translate="<?php echo $category['slug']; ?>">
                                <?php echo $category['name']; ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <li><a href="add_article.php" data-translate="add_article">लेख जोड़ें</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php if(isset($message)) echo $message; ?>

        <div class="main-content">
            <div class="news-grid">
                <?php foreach ($latest_articles as $article): ?>
                    <article class="news-card">
                        <a href="article.php?id=<?php echo $article['id']; ?>" style="text-decoration: none; color: inherit;">
                            <img src="<?php echo htmlspecialchars($article['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($article['title']); ?>" 
                                 class="news-image"
                                 onerror="this.src='uploads/default.jpg'">
                            <div class="news-content">
                                <div class="news-category"><?php echo htmlspecialchars($article['category_name']); ?></div>
                                <h2 class="news-title"><?php echo htmlspecialchars($article['title']); ?></h2>
                                <div class="news-meta">
                                    <span><i class="far fa-calendar"></i> <?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                    <span><i class="far fa-comment"></i> <?php echo $article['comment_count']; ?> टिप्पणियां</span>
                                    <span><i class="far fa-eye"></i> <?php echo $article['views']; ?> व्यूज</span>
                                </div>
                            </div>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>

            <aside class="sidebar">
                <h3 class="sidebar-title" data-translate="popular_news">लोकप्रिय समाचार</h3>
                <ul class="popular-list">
                    <?php foreach ($popular_articles as $article): ?>
                        <li class="popular-item">
                            <a href="article.php?id=<?php echo $article['id']; ?>" class="popular-link">
                                <img src="<?php echo htmlspecialchars($article['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($article['title']); ?>" 
                                     class="popular-image"
                                     onerror="this.src='uploads/default.jpg'">
                                <div>
                                    <h4><?php echo htmlspecialchars($article['title']); ?></h4>
                                    <span><i class="far fa-calendar"></i> <?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                </div>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </aside>
        </div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script src="js/translations.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>